#include <log4cplus/logger.h>
#include <log4cplus/configurator.h>
#include <log4cplus/helpers/loglog.h>
#include <log4cplus/helpers/fileinfo.h>
#include <log4cplus/loggingmacros.h>
#include <log4cplus/initializer.h>
// #include <thread>
#include <unistd.h>

int main(int argc, char * argv[])
{
    log4cplus::initialize();
    log4cplus::helpers::LogLog::getLogLog()->setInternalDebugging(true);

    try {
    	// 根据配置文件自动初始化日志
        log4cplus::tstring file = LOG4CPLUS_C_STR_TO_TSTRING("log4cplus.properties.3");
        log4cplus::helpers::FileInfo fi;
        if (getFileInfo (&fi, file) != 0) {
            log4cplus::tcout << LOG4CPLUS_TEXT("log4cplus.properties not exists") << std::endl;
            return -1;
        }
        log4cplus::ConfigureAndWatchThread configureThread(file, 5 * 1000);
    } catch(...) {
        log4cplus::tcout << LOG4CPLUS_TEXT("Exception...") << std::endl;
    }

    auto root = log4cplus::Logger::getRoot();
	auto logger_1 =  log4cplus::Logger::getInstance(LOG4CPLUS_TEXT("module_1"));
    auto logger_2 =  log4cplus::Logger::getInstance(LOG4CPLUS_TEXT("module_2"));

    LOG4CPLUS_TRACE(root, "printMsgs()");
    LOG4CPLUS_DEBUG(root, "printMsgs()");
    LOG4CPLUS_INFO(root, "printMsgs()");
    LOG4CPLUS_WARN(root, "printMsgs()");
    LOG4CPLUS_ERROR(root, "printMsgs()");
    LOG4CPLUS_INFO(root, "This is a int: " << 1000);

    LOG4CPLUS_TRACE(logger_1, "printMsgs()");
    LOG4CPLUS_DEBUG(logger_1, "printMsgs()");
    LOG4CPLUS_INFO(logger_1, "printMsgs()");
    LOG4CPLUS_WARN(logger_1, "printMsgs()");
    LOG4CPLUS_ERROR(logger_1, "printMsgs()");

    LOG4CPLUS_TRACE(logger_2, "printMsgs()");
    LOG4CPLUS_DEBUG(logger_2, "printMsgs()");
    LOG4CPLUS_INFO(logger_2, "printMsgs()");
    LOG4CPLUS_WARN(logger_2, "printMsgs()");
    LOG4CPLUS_ERROR(logger_2, "printMsgs()");

    sleep(30);

    log4cplus::deinitialize();

    return 0;
}
